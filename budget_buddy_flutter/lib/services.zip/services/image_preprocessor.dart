import 'dart:io';

import 'package:image/image.dart' as img;
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';

class ImagePreprocessor {
  Future<String> process(String imagePath) async {
    final file = File(imagePath);

    if (!await file.exists()) {
      throw Exception('Image not found.');
    }

    final bytes = await file.readAsBytes();

    img.Image? image = img.decodeImage(bytes);

    if (image == null) {
      throw Exception('Unable to decode image.');
    }

    // ----------------------------------------------------
    // Resize
    // ----------------------------------------------------

    const targetWidth = 1800;

    if (image.width > targetWidth) {
      image = img.copyResize(
        image,
        width: targetWidth,
        interpolation: img.Interpolation.cubic,
      );
    } else if (image.width < 1200) {
      image = img.copyResize(
        image,
        width: 1200,
        interpolation: img.Interpolation.cubic,
      );
    }

    // ----------------------------------------------------
    // Grayscale
    // ----------------------------------------------------

    image = img.grayscale(image);

    // ----------------------------------------------------
    // Brightness
    // ----------------------------------------------------

    image = img.adjustColor(
      image,
      brightness: 0.12,
    );

    // ----------------------------------------------------
    // Contrast
    // ----------------------------------------------------

    image = img.adjustColor(
      image,
      contrast: 1.6,
    );
    // ----------------------------------------------------
    // Sharpen
    // ----------------------------------------------------

    image = img.convolution(
      image,
      filter: const [
        0, -1, 0,
       -1,  5, -1,
        0, -1, 0,
      ],
    );

    // ----------------------------------------------------
    // Save
    // ----------------------------------------------------

    final tempDir = await getTemporaryDirectory();

    final processedPath = path.join(
      tempDir.path,
      'processed_${DateTime.now().millisecondsSinceEpoch}.jpg',
    );

    final processedFile = File(processedPath);

    await processedFile.writeAsBytes(
      img.encodeJpg(
        image,
        quality: 100,
      ),
    );

    return processedPath;
  }
}