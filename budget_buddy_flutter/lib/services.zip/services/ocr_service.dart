import 'dart:io';

import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

import 'image_preprocessor.dart';
import 'ocr_cleanup_service.dart';

class OcrService {
  final TextRecognizer _recognizer = TextRecognizer();
  final ImagePreprocessor _preprocessor = ImagePreprocessor();
  final OcrCleanupService _cleanup = OcrCleanupService();

  Future<String> extractText(String imagePath) async {
    try {
      String finalText = '';

      // Process original image
      final processedPath = await _preprocessor.process(imagePath);

      final candidates = <String>[
        imagePath,       // Original image
        processedPath,   // Enhanced image
      ];

      for (final path in candidates) {
        final file = File(path);

        if (!await file.exists()) continue;

        final inputImage = InputImage.fromFilePath(path);
        final recognizedText = await _recognizer.processImage(inputImage);

        final buffer = StringBuffer();

        // Keep receipt formatting line-by-line
        for (final block in recognizedText.blocks) {
          for (final line in block.lines) {
            final text = line.text.trim();

            if (text.isNotEmpty) {
              buffer.writeln(text);
            }
          }
        }

        final extracted = buffer.toString().trim();

        // Keep whichever OCR pass produced more text
        if (extracted.length > finalText.length) {
          finalText = extracted;
        }
      }

      // Fallback if blocks were empty
      if (finalText.isEmpty) {
        final inputImage = InputImage.fromFilePath(processedPath);
        final recognizedText =
            await _recognizer.processImage(inputImage);

        finalText = recognizedText.text.trim();
      }

      // Fix common OCR mistakes
      finalText = _cleanup.clean(finalText);

      return finalText;
    } catch (e) {
      throw Exception('OCR failed: $e');
    }
  }

  void dispose() {
    _recognizer.close();
  }
}