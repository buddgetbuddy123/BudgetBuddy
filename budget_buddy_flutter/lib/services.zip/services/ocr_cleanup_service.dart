class OcrCleanupService {
  String clean(String text) {
    String result = text;

    // Remove hidden characters
    result = result.replaceAll('\r', '');
    result = result.replaceAll('\t', ' ');
    result = result.replaceAll('\u00A0', ' ');

    final replacements = <String, String>{
      // ===== Receipt keywords =====
      'T0TAL': 'TOTAL',
      'TOTAI': 'TOTAL',
      'T0TAI': 'TOTAL',
      'T0TAL DUE': 'TOTAL DUE',

      '5UBTOTAL': 'SUBTOTAL',
      '5UB TOTAL': 'SUB TOTAL',

      'CA5H': 'CASH',
      'CA5': 'CASH',

      'CHAN6E': 'CHANGE',
      'CHANQE': 'CHANGE',

      'AM0UNT': 'AMOUNT',
      'AM0UNT DUE': 'AMOUNT DUE',

      'RECE1PT': 'RECEIPT',
      'MERCH4NT': 'MERCHANT',

      '1NVOICE': 'INVOICE',
      '1TEM': 'ITEM',
      '1TEMS': 'ITEMS',

      // ===== Months =====
      'JU1Y': 'JULY',
      'JANUARV': 'JANUARY',
      '0CT': 'OCT',
      'N0V': 'NOV',

      // ===== Currency =====
      'PHP.': 'PHP ',
      'PHP:': 'PHP ',
      'PHP,': 'PHP ',
      '₱ ': '₱',
      'P ': '₱',
    };

    replacements.forEach((wrong, correct) {
      result = result.replaceAll(
        RegExp(wrong, caseSensitive: false),
        correct,
      );
    });

    // Fix OCR mistakes inside numbers
    result = result.replaceAllMapped(
      RegExp(r'(?<=\d)[Oo](?=\d)'),
      (_) => '0',
    );

    result = result.replaceAllMapped(
      RegExp(r'(?<=\d)[Il](?=\d)'),
      (_) => '1',
    );

    result = result.replaceAllMapped(
      RegExp(r'(?<=₱)[Oo](?=\d)'),
      (_) => '0',
    );

    result = result.replaceAllMapped(
      RegExp(r'(?<=PHP )[Oo](?=\d)'),
      (_) => '0',
    );

    // Remove duplicate spaces
    result = result.replaceAll(RegExp(r'[ ]{2,}'), ' ');

    // Remove duplicate blank lines
    result = result.replaceAll(RegExp(r'\n{2,}'), '\n');

    return result.trim();
  }
}